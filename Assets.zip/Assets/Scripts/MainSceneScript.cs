using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;

public class MainSceneScript : MonoBehaviour
{
    public void Quit()
    {
        Debug.Log("Quitting Game...");
        Application.Quit();
    }

    public void LoadSceneFromButton()
    {
        string buttonName = EventSystem.current.currentSelectedGameObject.name;
        SceneManager.LoadScene(buttonName);
    }
}