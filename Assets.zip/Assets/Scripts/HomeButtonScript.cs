using UnityEngine;
using UnityEngine.SceneManagement;

public class HomeButtonScript : MonoBehaviour
{
    public void Home()
    {
        SceneManager.LoadScene(0);
    }
}
